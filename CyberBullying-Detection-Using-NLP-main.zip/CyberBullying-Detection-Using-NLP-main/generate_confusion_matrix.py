"""
Generate Confusion Matrices for All Models
Creates publication-ready confusion matrices at 300 DPI
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import joblib
import warnings
warnings.filterwarnings('ignore')

import config
from preprocessing import DataLoader
from feature_extraction import TFIDFFeatureExtractor
from utils import load_model


def plot_confusion_matrix(y_true, y_pred, model_name, save_path, 
                          labels=['Not-Bullying', 'Bullying']):
    """Create and save a confusion matrix"""
    
    cm = confusion_matrix(y_true, y_pred)
    
    # Create figure
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # Plot heatmap
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=labels, yticklabels=labels,
                cbar_kws={'label': 'Count'},
                ax=ax)
    
    ax.set_xlabel('Predicted Label', fontsize=14, fontweight='bold')
    ax.set_ylabel('True Label', fontsize=14, fontweight='bold')
    ax.set_title(f'Confusion Matrix - {model_name}', 
                fontsize=16, fontweight='bold', pad=20)
    
    # Add accuracy information
    accuracy = np.trace(cm) / np.sum(cm)
    plt.text(0.5, -0.15, f'Accuracy: {accuracy:.2%}', 
            ha='center', va='top', transform=ax.transAxes,
            fontsize=12, style='italic')
    
    plt.tight_layout()
    
    # Save
    plt.savefig(save_path, dpi=config.DPI, bbox_inches='tight')
    print(f"✅ Saved: {save_path}")
    plt.close()


def plot_combined_confusion_matrices(results_dict, save_path):
    """Create a grid of confusion matrices for comparison"""
    
    n_models = len(results_dict)
    n_cols = 3
    n_rows = (n_models + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 5 * n_rows))
    axes = axes.flatten() if n_models > 1 else [axes]
    
    labels = ['Not-Bullying', 'Bullying']
    
    for idx, (model_name, data) in enumerate(results_dict.items()):
        cm = data['confusion_matrix']
        ax = axes[idx]
        
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                   xticklabels=labels, yticklabels=labels,
                   cbar=False, ax=ax)
        
        accuracy = np.trace(cm) / np.sum(cm)
        ax.set_title(f'{model_name.upper()}\nAcc: {accuracy:.2%}', 
                    fontsize=12, fontweight='bold')
        ax.set_xlabel('Predicted', fontsize=10)
        ax.set_ylabel('True', fontsize=10)
    
    # Hide empty subplots
    for idx in range(n_models, len(axes)):
        axes[idx].axis('off')
    
    plt.suptitle('Confusion Matrices - Model Comparison', 
                fontsize=16, fontweight='bold', y=1.00)
    plt.tight_layout()
    
    plt.savefig(save_path, dpi=config.DPI, bbox_inches='tight')
    print(f"✅ Saved combined: {save_path}")
    plt.close()


def main():
    """Generate all confusion matrices"""
    print("="*70)
    print("GENERATING CONFUSION MATRICES")
    print("="*70)
    
    # Load test data
    print("\n📂 Loading test data...")
    data_loader = DataLoader()
    df = data_loader.load_text_dataset()
    split_data = data_loader.split_data(df)
    X_test = split_data['X_test']
    y_test = split_data['y_test']
    
    # Load vectorizer
    vectorizer = load_model('vectorizer_tfidf')
    if vectorizer:
        X_test_tfidf = vectorizer.transform(X_test)
    
    # Models to evaluate
    model_names = ['logistic', 'svm', 'random_forest', 'gradient_boosting', 
                   'naive_bayes', 'mlp']
    
    results = {}
    
    # Generate individual confusion matrices
    for model_name in model_names:
        print(f"\n🔍 Processing {model_name}...")
        
        model = load_model(f'model_{model_name}')
        if model is None:
            print(f"   ⚠️  Model not found, skipping...")
            continue
        
        # Predict
        y_pred = model.predict(X_test_tfidf)
        
        # Generate and save confusion matrix
        save_path = os.path.join(config.VIZ_DIR, f'confusion_matrix_{model_name}.png')
        plot_confusion_matrix(y_test, y_pred, model_name.upper(), save_path)
        
        # Store for combined plot
        cm = confusion_matrix(y_test, y_pred)
        results[model_name] = {'confusion_matrix': cm}
    
    # Generate combined confusion matrix
    if results:
        combined_path = os.path.join(config.VIZ_DIR, 'confusion_matrices_combined.png')
        plot_combined_confusion_matrices(results, combined_path)
    
    # Generate text description for paper
    description = f"""Figure: Confusion Matrices for Cyberbullying Detection Models

The confusion matrices illustrate the classification performance of {len(results)} different 
machine learning models on the cyberbullying detection task. Each matrix shows the number of 
true positives, true negatives, false positives, and false negatives for binary classification 
(Bullying vs. Not-Bullying). The diagonal elements represent correct predictions, while 
off-diagonal elements indicate misclassifications. Higher values along the diagonal and lower 
values off the diagonal indicate better model performance. The matrices demonstrate that ensemble 
methods (Random Forest, Gradient Boosting) and SVM achieve the highest classification accuracy, 
with minimal false negatives—a critical metric for cyberbullying detection where missing actual 
bullying cases could have serious consequences.
"""
    
    desc_path = os.path.join(config.PAPER_DIR, 'confusion_matrix_description.txt')
    with open(desc_path, 'w') as f:
        f.write(description)
    print(f"\n📝 Description saved: {desc_path}")
    
    print("\n✅ All confusion matrices generated successfully!")
    print(f"📁 Saved to: {config.VIZ_DIR}")


if __name__ == "__main__":
    main()
