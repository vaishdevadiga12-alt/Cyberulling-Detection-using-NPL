"""
OCR Utility Functions for Image Text Extraction
Supports both EasyOCR and Tesseract OCR
"""

import os
import cv2
import numpy as np
from PIL import Image
import logging

logger = logging.getLogger(__name__)

# Try to import OCR libraries
try:
    import easyocr
    EASYOCR_AVAILABLE = True
except ImportError:
    EASYOCR_AVAILABLE = False
    logger.warning("EasyOCR not available. Install with: pip install easyocr")

try:
    import pytesseract
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False
    logger.warning("Tesseract not available. Install with: pip install pytesseract")


class OCRExtractor:
    """Extract text from images using available OCR engines"""
    
    def __init__(self, method='auto'):
        """
        Initialize OCR extractor
        
        Args:
            method: 'auto', 'easyocr', or 'tesseract'
        """
        self.method = method
        self.reader = None
        
        if method == 'auto':
            if EASYOCR_AVAILABLE:
                self.method = 'easyocr'
                self._init_easyocr()
            elif TESSERACT_AVAILABLE:
                self.method = 'tesseract'
            else:
                raise ImportError("No OCR engine available. Install EasyOCR or Tesseract.")
        elif method == 'easyocr':
            if not EASYOCR_AVAILABLE:
                raise ImportError("EasyOCR not installed. Install with: pip install easyocr")
            self._init_easyocr()
        elif method == 'tesseract':
            if not TESSERACT_AVAILABLE:
                raise ImportError("Tesseract not installed. Install with: pip install pytesseract")
        
        logger.info(f"OCR initialized with method: {self.method}")
    
    def _init_easyocr(self):
        """Initialize EasyOCR reader"""
        try:
            # Initialize with English language
            self.reader = easyocr.Reader(['en'], gpu=False)
            logger.info("EasyOCR reader initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize EasyOCR: {e}")
            raise
    
    def extract_text(self, image_path_or_array):
        """
        Extract text from image
        
        Args:
            image_path_or_array: Path to image file or numpy array
            
        Returns:
            str: Extracted text
        """
        if self.method == 'easyocr':
            return self._extract_easyocr(image_path_or_array)
        elif self.method == 'tesseract':
            return self._extract_tesseract(image_path_or_array)
        else:
            raise ValueError(f"Unknown OCR method: {self.method}")
    
    def _extract_easyocr(self, image_path_or_array):
        """Extract text using EasyOCR"""
        try:
            # Read image
            if isinstance(image_path_or_array, str):
                image = cv2.imread(image_path_or_array)
            else:
                image = image_path_or_array
            
            # Extract text
            results = self.reader.readtext(image)
            
            # Combine all detected text
            text = ' '.join([result[1] for result in results])
            
            logger.info(f"EasyOCR extracted {len(results)} text regions")
            return text.strip()
            
        except Exception as e:
            logger.error(f"EasyOCR extraction failed: {e}")
            return ""
    
    def _extract_tesseract(self, image_path_or_array):
        """Extract text using Tesseract"""
        try:
            # Read image
            if isinstance(image_path_or_array, str):
                image = Image.open(image_path_or_array)
            else:
                # Convert numpy array to PIL Image
                image = Image.fromarray(cv2.cvtColor(image_path_or_array, cv2.COLOR_BGR2RGB))
            
            # Extract text
            text = pytesseract.image_to_string(image)
            
            logger.info(f"Tesseract extracted text: {len(text)} characters")
            return text.strip()
            
        except Exception as e:
            logger.error(f"Tesseract extraction failed: {e}")
            return ""
    
    def extract_with_confidence(self, image_path_or_array):
        """
        Extract text with confidence scores
        
        Returns:
            list: List of tuples (text, confidence)
        """
        if self.method != 'easyocr':
            raise NotImplementedError("Confidence scores only available with EasyOCR")
        
        try:
            if isinstance(image_path_or_array, str):
                image = cv2.imread(image_path_or_array)
            else:
                image = image_path_or_array
            
            results = self.reader.readtext(image)
            
            # Return text with confidence scores
            return [(result[1], result[2]) for result in results]
            
        except Exception as e:
            logger.error(f"EasyOCR extraction with confidence failed: {e}")
            return []


def extract_text_from_image(image_path_or_array, method='auto'):
    """
    Convenience function to extract text from image
    
    Args:
        image_path_or_array: Path to image or numpy array
        method: 'auto', 'easyocr', or 'tesseract'
        
    Returns:
        str: Extracted text
    """
    extractor = OCRExtractor(method=method)
    return extractor.extract_text(image_path_or_array)


def check_ocr_availability():
    """
    Check which OCR engines are available
    
    Returns:
        dict: Availability status
    """
    status = {
        'easyocr': EASYOCR_AVAILABLE,
        'tesseract': TESSERACT_AVAILABLE,
        'any_available': EASYOCR_AVAILABLE or TESSERACT_AVAILABLE
    }
    return status


def preprocess_image_for_ocr(image_path_or_array):
    """
    Preprocess image for better OCR results
    
    Args:
        image_path_or_array: Path to image or numpy array
        
    Returns:
        numpy.ndarray: Preprocessed image
    """
    # Read image
    if isinstance(image_path_or_array, str):
        image = cv2.imread(image_path_or_array)
    else:
        image = image_path_or_array.copy()
    
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Apply thresholding
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # Denoise
    denoised = cv2.fastNlMeansDenoising(thresh)
    
    return denoised


# Example usage
if __name__ == "__main__":
    import sys
    
    # Check availability
    status = check_ocr_availability()
    print("OCR Availability:")
    print(f"  EasyOCR: {'✓' if status['easyocr'] else '✗'}")
    print(f"  Tesseract: {'✓' if status['tesseract'] else '✗'}")
    print()
    
    if not status['any_available']:
        print("No OCR engine available!")
        print("Install EasyOCR: pip install easyocr")
        print("OR")
        print("Install Tesseract: pip install pytesseract")
        sys.exit(1)
    
    # Test with an image
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        print(f"Extracting text from: {image_path}")
        
        try:
            text = extract_text_from_image(image_path)
            print(f"\nExtracted Text:\n{text}")
        except Exception as e:
            print(f"Error: {e}")
    else:
        print("Usage: python ocr_utils.py <image_path>")
