"""
Data Preprocessing Module for Cyberbullying Detection
Handles text cleaning, label normalization, image preprocessing, and data augmentation
"""

import re
import os
import pandas as pd
import numpy as np
from PIL import Image
import cv2
from sklearn.model_selection import train_test_split
from sklearn.utils import class_weight
from imblearn.over_sampling import SMOTE
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import warnings
warnings.filterwarnings('ignore')

# Download NLTK data
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords', quiet=True)
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet', quiet=True)
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)

import config


class TextPreprocessor:
    """Text preprocessing for cyberbullying detection"""
    
    def __init__(self, remove_stopwords=False, lemmatize=False):
        self.remove_stopwords = remove_stopwords
        self.lemmatize = lemmatize
        if remove_stopwords:
            self.stop_words = set(stopwords.words('english'))
        if lemmatize:
            self.lemmatizer = WordNetLemmatizer()
    
    def clean_text(self, text):
        """Clean and normalize text"""
        if pd.isna(text) or text is None:
            return ""
        
        text = str(text).lower()
        
        # Remove URLs
        text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
        
        # Remove user mentions and hashtags
        text = re.sub(r'@\w+|#\w+', '', text)
        
        # Remove emails
        text = re.sub(r'\S+@\S+', '', text)
        
        # Remove numbers (optional - may want to keep for context)
        # text = re.sub(r'\d+', '', text)
        
        # Remove special characters but keep some punctuation for context
        text = re.sub(r'[^a-z\s\.\!\?]', ' ', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        # Remove very short words
        words = text.split()
        words = [w for w in words if len(w) >= config.MIN_WORD_LENGTH]
        
        # Remove stopwords if enabled
        if self.remove_stopwords:
            words = [w for w in words if w not in self.stop_words]
        
        # Lemmatize if enabled
        if self.lemmatize:
            words = [self.lemmatizer.lemmatize(w) for w in words]
        
        return ' '.join(words)
    
    def batch_clean(self, texts):
        """Clean multiple texts"""
        return [self.clean_text(text) for text in texts]


class LabelProcessor:
    """Process and normalize labels from various formats"""
    
    @staticmethod
    def normalize_binary_labels(labels):
        """
        Normalize labels to binary format (0: Not-Bullying, 1: Bullying)
        Handles various formats from the dataset
        """
        normalized = []
        
        for label in labels:
            label_str = str(label).strip().lower()
            
            # Check for variations of "not bullying"
            if any(pattern in label_str for pattern in ['not-bullying', 'not bullying', 'notbullying', 'not - bullying', 'not -bullying']):
                normalized.append(0)
            # Check for bullying
            elif 'bully' in label_str:
                normalized.append(1)
            # Try numeric
            else:
                try:
                    val = int(float(label_str))
                    normalized.append(1 if val == 1 else 0)
                except:
                    # Default to not-bullying if unclear
                    normalized.append(0)
        
        return np.array(normalized)
    
    @staticmethod
    def extract_categories(types_column):
        """
        Extract cyberbullying categories from Types column
        Returns: harassment, hate_speech, offensive, threat, or normal
        """
        categories = []
        
        for cat in types_column:
            if pd.isna(cat) or cat == '':
                categories.append('normal')
                continue
            
            cat_str = str(cat).strip().lower()
            
            if 'threat' in cat_str:
                categories.append('threat')
            elif 'ethnic' in cat_str or 'religion' in cat_str or 'racist' in cat_str:
                categories.append('hate_speech')
            elif 'sexual' in cat_str or 'vocational' in cat_str:
                categories.append('harassment')
            elif 'political' in cat_str or 'troll' in cat_str:
                categories.append('offensive')
            else:
                categories.append('offensive')  # Default
        
        return categories
    
    @staticmethod
    def assign_severity(text, label):
        """
        Assign severity level based on text content
        Returns: mild, moderate, severe, or none
        """
        if label == 0:  # Not bullying
            return 'none'
        
        text_lower = str(text).lower()
        
        # Severe indicators
        severe_keywords = ['kill', 'die', 'death', 'murder', 'rape', 'shoot', 'bomb']
        if any(word in text_lower for word in severe_keywords):
            return 'severe'
        
        # Moderate indicators
        moderate_keywords = ['hate', 'stupid', 'idiot', 'ugly', 'loser', 'trash', 'scum']
        if any(word in text_lower for word in moderate_keywords):
            return 'moderate'
        
        # Mild by default
        return 'mild'


class ImagePreprocessor:
    """Image preprocessing for meme analysis"""
    
    def __init__(self, target_size=config.IMG_SIZE, augment=False):
        self.target_size = target_size
        self.augment = augment
    
    def load_and_preprocess(self, image_path):
        """Load and preprocess a single image"""
        try:
            # Load image
            img = Image.open(image_path).convert('RGB')
            
            # Resize
            img = img.resize(self.target_size, Image.LANCZOS)
            
            # Convert to array
            img_array = np.array(img) / 255.0  # Normalize to [0, 1]
            
            return img_array
        
        except Exception as e:
            print(f"Error loading image {image_path}: {e}")
            # Return blank image
            return np.zeros((*self.target_size, 3))
    
    def augment_image(self, img_array):
        """Apply data augmentation"""
        if not self.augment:
            return img_array
        
        # Random rotation
        if np.random.rand() > 0.5:
            angle = np.random.randint(-config.IMG_AUG_ROTATION, config.IMG_AUG_ROTATION)
            img_array = self._rotate_image(img_array, angle)
        
        # Random horizontal flip
        if config.IMG_AUG_FLIP and np.random.rand() > 0.5:
            img_array = np.fliplr(img_array)
        
        # Random brightness adjustment
        if np.random.rand() > 0.5:
            factor = 1 + np.random.uniform(-config.IMG_AUG_BRIGHTNESS, config.IMG_AUG_BRIGHTNESS)
            img_array = np.clip(img_array * factor, 0, 1)
        
        return img_array
    
    @staticmethod
    def _rotate_image(img_array, angle):
        """Rotate image by angle"""
        h, w = img_array.shape[:2]
        center = (w // 2, h // 2)
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(img_array, M, (w, h))
        return rotated


class DataLoader:
    """Load and prepare datasets for training"""
    
    def __init__(self):
        self.text_preprocessor = TextPreprocessor()
        self.label_processor = LabelProcessor()
    
    def load_text_dataset(self, csv_path=config.TEXT_DATASET, sample_size=None):
        """
        Load text dataset from CSV
        Returns: DataFrame with cleaned text, labels, categories, severity
        """
        print(f"📂 Loading text dataset from: {csv_path}")
        
        # Load CSV
        df = pd.read_csv(csv_path, encoding='utf-8', engine='python', on_bad_lines='skip')
        
        # Sample if needed (for faster development)
        if sample_size and sample_size < len(df):
            df = df.sample(n=sample_size, random_state=config.RANDOM_SEED)
        
        # Normalize column names
        cols = [c.lower() for c in df.columns]
        if 'text' in cols and 'label' in cols:
            text_col = df.columns[cols.index('text')]
            label_col = df.columns[cols.index('label')]
            types_col = df.columns[cols.index('types')] if 'types' in cols else None
        else:
            text_col = df.columns[0]
            label_col = df.columns[1]
            types_col = df.columns[2] if len(df.columns) > 2 else None
        
        # Clean and process
        df['text_original'] = df[text_col]
        df['text_cleaned'] = self.text_preprocessor.batch_clean(df[text_col])
        df['label_binary'] = self.label_processor.normalize_binary_labels(df[label_col])
        
        # Extract categories if Types column exists
        if types_col:
            df['category'] = self.label_processor.extract_categories(df[types_col])
        else:
            df['category'] = df['label_binary'].apply(lambda x: 'normal' if x == 0 else 'offensive')
        
        # Assign severity
        df['severity'] = df.apply(lambda row: self.label_processor.assign_severity(
            row['text_original'], row['label_binary']), axis=1)
        
        # Remove empty texts
        df = df[df['text_cleaned'].str.len() > 0].reset_index(drop=True)
        
        print(f"✅ Loaded {len(df)} samples")
        print(f"📊 Label distribution:\n{df['label_binary'].value_counts()}")
        print(f"📊 Category distribution:\n{df['category'].value_counts()}")
        
        return df
    
    def split_data(self, df, test_size=config.TEST_SIZE, val_size=config.VAL_SIZE):
        """Split data into train, validation, and test sets"""
        X = df['text_cleaned'].values
        y = df['label_binary'].values
        
        # First split: train+val vs test
        X_temp, X_test, y_temp, y_test = train_test_split(
            X, y, test_size=test_size, random_state=config.RANDOM_SEED, stratify=y
        )
        
        # Second split: train vs val
        if val_size > 0:
            val_ratio = val_size / (1 - test_size)
            X_train, X_val, y_train, y_val = train_test_split(
                X_temp, y_temp, test_size=val_ratio, 
                random_state=config.RANDOM_SEED, stratify=y_temp
            )
        else:
            X_train, X_val = X_temp, np.array([])
            y_train, y_val = y_temp, np.array([])
        
        print(f"\n📊 Data split:")
        print(f"   Train: {len(X_train)} samples")
        print(f"   Val:   {len(X_val)} samples")
        print(f"   Test:  {len(X_test)} samples")
        
        return {
            'X_train': X_train, 'y_train': y_train,
            'X_val': X_val, 'y_val': y_val,
            'X_test': X_test, 'y_test': y_test
        }
    
    def handle_imbalance(self, X_train, y_train, method='smote'):
        """Handle class imbalance using SMOTE or class weights"""
        print(f"\n⚖️  Handling class imbalance with {method}...")
        
        if method == 'smote' and config.USE_SMOTE:
            # Use SMOTE for oversampling
            from sklearn.feature_extraction.text import TfidfVectorizer
            
            # Vectorize for SMOTE (needs numeric features)
            vectorizer = TfidfVectorizer(max_features=1000)
            X_vec = vectorizer.fit_transform(X_train)
            
            smote = SMOTE(sampling_strategy=config.SMOTE_SAMPLING_STRATEGY, 
                         random_state=config.RANDOM_SEED)
            X_resampled, y_resampled = smote.fit_resample(X_vec, y_train)
            
            # Convert back to text (approximation - use original samples)
            print(f"   Original: {len(y_train)} samples")
            print(f"   Resampled: {len(y_resampled)} samples")
            
            return X_train, y_train  # Return original for now
        
        elif method == 'weights' and config.USE_CLASS_WEIGHTS:
            # Calculate class weights
            classes = np.unique(y_train)
            weights = class_weight.compute_class_weight(
                'balanced', classes=classes, y=y_train
            )
            class_weights_dict = dict(zip(classes, weights))
            
            print(f"   Class weights: {class_weights_dict}")
            return X_train, y_train, class_weights_dict
        
        return X_train, y_train


def main():
    """Test preprocessing functions"""
    print("=" * 60)
    print("Testing Cyberbullying Detection Preprocessing")
    print("=" * 60)
    
    # Test text preprocessing
    loader = DataLoader()
    
    try:
        df = loader.load_text_dataset(sample_size=1000)
        
        print(f"\n📋 Sample rows:")
        print(df[['text_cleaned', 'label_binary', 'category', 'severity']].head(10))
        
        # Test train/test split
        split_data = loader.split_data(df)
        
        print(f"\n✅ Preprocessing test completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
