"""
Train Multiple Text Classification Models for Cyberbullying Detection
Includes: BERT, DistilBERT, LSTM, CNN, SVM, Logistic Regression, Random Forest, Naive Bayes
"""

import os
import time
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import LinearSVC, SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import cross_val_score
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from torch.optim import AdamW
from transformers import BertForSequenceClassification, DistilBertForSequenceClassification
from transformers import BertTokenizer, DistilBertTokenizer
from transformers import get_linear_schedule_with_warmup
import warnings
warnings.filterwarnings('ignore')

import config
from preprocessing import DataLoader as CyberDataLoader, TextPreprocessor
from feature_extraction import TFIDFFeatureExtractor, BERTFeatureExtractor, DistilBERTFeatureExtractor, Word2VecFeatureExtractor
from utils import (save_model, calculate_metrics, print_metrics, 
                  save_results, PerformanceTracker, create_logger)


class LSTMClassifier(nn.Module):
    """LSTM-based text classifier"""
    
    def __init__(self, vocab_size=config.VOCAB_SIZE, embedding_dim=config.EMBEDDING_DIM,
                 hidden_dim=config.LSTM_UNITS, num_classes=2):
        super(LSTMClassifier, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True, 
                           bidirectional=True, dropout=config.LSTM_DROPOUT)
        self.fc = nn.Linear(hidden_dim * 2, num_classes)
        self.dropout = nn.Dropout(config.LSTM_DROPOUT)
    
    def forward(self, x):
        embedded = self.embedding(x)
        lstm_out, (hidden, cell) = self.lstm(embedded)
        # Concatenate final forward and backward hidden states
        hidden_concat = torch.cat((hidden[-2,:,:], hidden[-1,:,:]), dim=1)
        hidden_concat = self.dropout(hidden_concat)
        output = self.fc(hidden_concat)
        return output


class CNNTextClassifier(nn.Module):
    """CNN-based text classifier"""
    
    def __init__(self, vocab_size=config.VOCAB_SIZE, embedding_dim=config.EMBEDDING_DIM,
                 num_filters=config.CNN_FILTERS, kernel_sizes=config.CNN_KERNEL_SIZES, 
                 num_classes=2):
        super(CNNTextClassifier, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        
        # Multiple convolutional layers with different kernel sizes
        self.convs = nn.ModuleList([
            nn.Conv1d(embedding_dim, num_filters[i], kernel_size=k)
            for i, k in enumerate(kernel_sizes)
        ])
        
        self.dropout = nn.Dropout(config.CNN_DROPOUT)
        self.fc = nn.Linear(sum(num_filters), num_classes)
    
    def forward(self, x):
        embedded = self.embedding(x).permute(0, 2, 1)  # (batch, embedding_dim, seq_len)
        
        # Apply convolutions and max pooling
        conv_outputs = []
        for conv in self.convs:
            conv_out = torch.relu(conv(embedded))
            pooled = torch.max_pool1d(conv_out, conv_out.size(2)).squeeze(2)
            conv_outputs.append(pooled)
        
        # Concatenate all outputs
        concat = torch.cat(conv_outputs, dim=1)
        concat = self.dropout(concat)
        output = self.fc(concat)
        return output


class TextModelTrainer:
    """Train and evaluate multiple text classification models"""
    
    def __init__(self, output_dir=config.MODELS_DIR):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.logger = create_logger('TextModelTrainer', 'text_training.log')
        self.results = {}
        self.tracker = PerformanceTracker()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.logger.info(f"Using device: {self.device}")
    
    def train_traditional_ml(self, X_train, X_test, y_train, y_test, model_type='logistic'):
        """Train traditional ML models (LogisticRegression, SVM, RF, etc.)"""
        self.logger.info(f"\n{'='*60}")
        self.logger.info(f"Training {model_type.upper()} Model")
        self.logger.info(f"{'='*60}")
        
        start_time = time.time()
        
        # Select model
        if model_type == 'logistic':
            model = LogisticRegression(max_iter=1000, class_weight='balanced', random_state=config.RANDOM_SEED)
        elif model_type == 'svm':
            model = LinearSVC(max_iter=5000, class_weight='balanced', random_state=config.RANDOM_SEED)
        elif model_type == 'random_forest':
            model = RandomForestClassifier(n_estimators=200, class_weight='balanced', 
                                          random_state=config.RANDOM_SEED, n_jobs=-1)
        elif model_type == 'gradient_boosting':
            model = GradientBoostingClassifier(n_estimators=100, random_state=config.RANDOM_SEED)
        elif model_type == 'naive_bayes':
            model = MultinomialNB()
        elif model_type == 'mlp':
            model = MLPClassifier(hidden_layer_sizes=(256, 128), max_iter=500, 
                                random_state=config.RANDOM_SEED)
        else:
            raise ValueError(f"Unknown model type: {model_type}")
        
        # Train
        self.logger.info("Training...")
        model.fit(X_train, y_train)
        
        # Predict
        y_pred = model.predict(X_test)
        
        # For probability scores (if available)
        try:
            y_proba = model.predict_proba(X_test)[:, 1]
        except:
            try:
                y_proba = model.decision_function(X_test)
            except:
                y_proba = None
        
        # Calculate metrics
        metrics = calculate_metrics(y_test, y_pred, y_proba)
        
        training_time = time.time() - start_time
        metrics['training_time'] = training_time
        
        # Save model
        model_name = f"model_{model_type}"
        save_model(model, model_name, self.output_dir)
        
        # Log results
        print_metrics(metrics, model_type.upper())
        self.results[model_type] = metrics
        self.tracker.add_result(model_type, metrics)
        
        return model, metrics
    
    def train_bert(self, train_texts, train_labels, val_texts, val_labels, 
                   test_texts, test_labels, model_type='bert'):
        """Fine-tune BERT or DistilBERT"""
        self.logger.info(f"\n{'='*60}")
        self.logger.info(f"Fine-tuning {model_type.upper()} Model")
        self.logger.info(f"{'='*60}")
        
        start_time = time.time()
        
        # Load tokenizer and model
        if model_type == 'bert':
            tokenizer = BertTokenizer.from_pretrained(config.BERT_MODEL_NAME)
            model = BertForSequenceClassification.from_pretrained(
                config.BERT_MODEL_NAME, num_labels=2
            )
        else:  # distilbert
            tokenizer = DistilBertTokenizer.from_pretrained(config.DISTILBERT_MODEL_NAME)
            model = DistilBertForSequenceClassification.from_pretrained(
                config.DISTILBERT_MODEL_NAME, num_labels=2
            )
        
        model.to(self.device)
        
        # Tokenize
        def tokenize_data(texts, labels):
            encodings = tokenizer(
                texts.tolist() if isinstance(texts, np.ndarray) else list(texts),
                truncation=True,
                padding=True,
                max_length=config.MAX_LENGTH,
                return_tensors='pt'
            )
            dataset = TensorDataset(
                encodings['input_ids'],
                encodings['attention_mask'],
                torch.tensor(labels)
            )
            return dataset
        
        train_dataset = tokenize_data(train_texts, train_labels)
        val_dataset = tokenize_data(val_texts, val_labels)
        
        train_loader = DataLoader(train_dataset, batch_size=config.BATCH_SIZE, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=config.BATCH_SIZE)
        
        # Optimizer and scheduler
        optimizer = AdamW(model.parameters(), lr=config.LEARNING_RATE)
        total_steps = len(train_loader) * config.EPOCHS_BERT
        scheduler = get_linear_schedule_with_warmup(
            optimizer, num_warmup_steps=config.WARMUP_STEPS,
            num_training_steps=total_steps
        )
        
        # Training loop
        best_val_acc = 0
        history = {'train_loss': [], 'train_acc': [], 'val_loss': [], 'val_acc': []}
        
        for epoch in range(config.EPOCHS_BERT):
            model.train()
            train_loss = 0
            train_correct = 0
            train_total = 0
            
            for batch in train_loader:
                input_ids, attention_mask, labels = [b.to(self.device) for b in batch]
                
                optimizer.zero_grad()
                outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                loss = outputs.loss
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), config.MAX_GRAD_NORM)
                optimizer.step()
                scheduler.step()
                
                train_loss += loss.item()
                _, predicted = torch.max(outputs.logits, 1)
                train_correct += (predicted == labels).sum().item()
                train_total += labels.size(0)
            
            train_acc = train_correct / train_total
            
            # Validation
            model.eval()
            val_loss = 0
            val_correct = 0
            val_total = 0
            
            with torch.no_grad():
                for batch in val_loader:
                    input_ids, attention_mask, labels = [b.to(self.device) for b in batch]
                    outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                    
                    val_loss += outputs.loss.item()
                    _, predicted = torch.max(outputs.logits, 1)
                    val_correct += (predicted == labels).sum().item()
                    val_total += labels.size(0)
            
            val_acc = val_correct / val_total
            
            history['train_loss'].append(train_loss/len(train_loader))
            history['train_acc'].append(train_acc)
            history['val_loss'].append(val_loss/len(val_loader))
            history['val_acc'].append(val_acc)
            
            self.logger.info(f"Epoch {epoch+1}/{config.EPOCHS_BERT} - "
                           f"Train Loss: {train_loss/len(train_loader):.4f}, "
                           f"Train Acc: {train_acc:.4f}, "
                           f"Val Loss: {val_loss/len(val_loader):.4f}, "
                           f"Val Acc: {val_acc:.4f}")
            
            # Save best model
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                save_model(model, f"model_{model_type}_best", self.output_dir)
        
        # Evaluate on test set
        test_dataset = tokenize_data(test_texts, test_labels)
        test_loader = DataLoader(test_dataset, batch_size=config.BATCH_SIZE)
        
        model.eval()
        all_preds = []
        all_probs = []
        all_labels = []
        
        with torch.no_grad():
            for batch in test_loader:
                input_ids, attention_mask, labels = [b.to(self.device) for b in batch]
                outputs = model(input_ids=input_ids, attention_mask=attention_mask)
                
                probs = torch.softmax(outputs.logits, dim=1)
                _, predicted = torch.max(outputs.logits, 1)
                
                all_preds.extend(predicted.cpu().numpy())
                all_probs.extend(probs[:, 1].cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
        
        # Calculate metrics
        metrics = calculate_metrics(np.array(all_labels), np.array(all_preds), np.array(all_probs))
        training_time = time.time() - start_time
        metrics['training_time'] = training_time
        metrics['history'] = history
        
        # Save final model
        save_model(model, f"model_{model_type}", self.output_dir)
        
        # Log results
        print_metrics(metrics, model_type.upper())
        self.results[model_type] = metrics
        self.tracker.add_result(model_type, metrics)
        
        return model, metrics
    
    def compare_models(self):
        """Compare all trained models"""
        print(f"\n{'='*70}")
        print("MODEL COMPARISON SUMMARY")
        print(f"{'='*70}")
        
        comparison_df = pd.DataFrame(self.results).T
        comparison_df = comparison_df.round(4)
        comparison_df = comparison_df.sort_values('f1', ascending=False)
        
        print(comparison_df.to_string())
        
        # Save comparison
        comparison_path = os.path.join(config.PAPER_DIR, 'model_comparison.csv')
        comparison_df.to_csv(comparison_path)
        print(f"\n💾 Comparison saved: {comparison_path}")
        
        # Get best model
        best_model = comparison_df.iloc[0]
        print(f"\n🏆 Best Model: {best_model.name}")
        print(f"   F1-Score: {best_model['f1']:.4f}")
        print(f"   Accuracy: {best_model['accuracy']:.4f}")
        
        return comparison_df


def main():
    """Main training pipeline"""
    print("="*70)
    print("CYBERBULLYING DETECTION - TEXT MODEL TRAINING")
    print("="*70)
    
    # Load data
    print("\n📂 Loading and preprocessing data...")
    data_loader = CyberDataLoader()
    df = data_loader.load_text_dataset(sample_size=None)  # Use full dataset
    
    # Split data
    split_data = data_loader.split_data(df)
    X_train, y_train = split_data['X_train'], split_data['y_train']
    X_val, y_val = split_data['X_val'], split_data['y_val']
    X_test, y_test = split_data['X_test'], split_data['y_test']
    
    # Initialize trainer
    trainer = TextModelTrainer()
    
    # Extract features for traditional ML models
    print("\n🔧 Extracting TF-IDF features for traditional models...")
    tfidf_extractor = TFIDFFeatureExtractor()
    X_train_tfidf = tfidf_extractor.fit_transform(X_train)
    X_test_tfidf = tfidf_extractor.transform(X_test)
    
    # Save vectorizer
    save_model(tfidf_extractor.vectorizer, 'vectorizer_tfidf', config.MODELS_DIR)
    
    # Train traditional ML models
    print("\n" + "="*70)
    print("TRAINING TRADITIONAL MACHINE LEARNING MODELS")
    print("="*70)
    
    # 1. Logistic Regression
    trainer.train_traditional_ml(X_train_tfidf, X_test_tfidf, y_train, y_test, 'logistic')
    
    # 2. Linear SVM
    trainer.train_traditional_ml(X_train_tfidf, X_test_tfidf, y_train, y_test, 'svm')
    
    # 3. Random Forest
    trainer.train_traditional_ml(X_train_tfidf, X_test_tfidf, y_train, y_test, 'random_forest')
    
    # 4. Gradient Boosting
    trainer.train_traditional_ml(X_train_tfidf, X_test_tfidf, y_train, y_test, 'gradient_boosting')
    
    # 5. Naive Bayes
    trainer.train_traditional_ml(X_train_tfidf, X_test_tfidf, y_train, y_test, 'naive_bayes')
    
    # 6. MLP (Neural Network)
    trainer.train_traditional_ml(X_train_tfidf, X_test_tfidf, y_train, y_test, 'mlp')
    
    # Train deep learning models (optional - comment out if too slow)
    if torch.cuda.is_available() or input("\n🤖 Train BERT models? (y/n): ").lower() == 'y':
        print("\n" + "="*70)
        print("TRAINING DEEP LEARNING MODELS")
        print("="*70)
        
        # 7. DistilBERT (faster than BERT)
        trainer.train_bert(X_train, y_train, X_val, y_val, X_test, y_test, 'distilbert')
        
        # 8. BERT (optional - slower)
        # trainer.train_bert(X_train, y_train, X_val, y_val, X_test, y_test, 'bert')
    
    # Compare all models
    print("\n" + "="*70)
    print("FINAL COMPARISON")
    print("="*70)
    comparison = trainer.compare_models()
    
    # Save tracker
    trainer.tracker.save()
    
    print("\n✅ Training completed successfully!")
    print(f"📁 Models saved in: {config.MODELS_DIR}")
    print(f"📊 Results saved in: {config.PAPER_DIR}")


if __name__ == "__main__":
    main()
