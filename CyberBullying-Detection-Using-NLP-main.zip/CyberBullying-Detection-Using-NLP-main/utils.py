"""
Utility functions for Cyberbullying Detection System
"""

import os
import json
import pickle
import joblib
import numpy as np
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    confusion_matrix, classification_report, 
    accuracy_score, precision_score, recall_score, f1_score,
    roc_curve, auc, precision_recall_curve, average_precision_score
)
import config


def save_model(model, model_name, model_dir=config.MODELS_DIR):
    """Save model to disk"""
    os.makedirs(model_dir, exist_ok=True)
    filepath = os.path.join(model_dir, f"{model_name}.pkl")
    joblib.dump(model, filepath)
    print(f"💾 Model saved: {filepath}")
    return filepath


def load_model(model_name, model_dir=config.MODELS_DIR):
    """Load model from disk"""
    filepath = os.path.join(model_dir, f"{model_name}.pkl")
    if os.path.exists(filepath):
        model = joblib.load(filepath)
        print(f"✅ Model loaded: {filepath}")
        return model
    else:
        print(f"❌ Model not found: {filepath}")
        return None


def save_results(results, filename, output_dir=config.PAPER_DIR):
    """Save results to JSON file"""
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)
    
    # Convert numpy types to Python types
    def convert_types(obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        return obj
    
    results_converted = {k: convert_types(v) for k, v in results.items()}
    
    with open(filepath, 'w') as f:
        json.dump(results_converted, f, indent=4)
    
    print(f"💾 Results saved: {filepath}")


def calculate_metrics(y_true, y_pred, y_proba=None):
    """Calculate comprehensive evaluation metrics"""
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred, average=config.AVERAGE_TYPE, zero_division=0),
        'recall': recall_score(y_true, y_pred, average=config.AVERAGE_TYPE, zero_division=0),
        'f1': f1_score(y_true, y_pred, average=config.AVERAGE_TYPE, zero_division=0),
    }
    
    # Add AUC if probabilities provided
    if y_proba is not None:
        if len(np.unique(y_true)) == 2:  # Binary classification
            fpr, tpr, _ = roc_curve(y_true, y_proba)
            metrics['auc'] = auc(fpr, tpr)
            metrics['average_precision'] = average_precision_score(y_true, y_proba)
    
    return metrics


def print_metrics(metrics, model_name="Model"):
    """Print metrics in a formatted way"""
    print(f"\n{'='*60}")
    print(f"📊 {model_name} Performance Metrics")
    print(f"{'='*60}")
    print(f"Accuracy:  {metrics['accuracy']:.4f}")
    print(f"Precision: {metrics['precision']:.4f}")
    print(f"Recall:    {metrics['recall']:.4f}")
    print(f"F1-Score:  {metrics['f1']:.4f}")
    if 'auc' in metrics:
        print(f"AUC:       {metrics['auc']:.4f}")
    if 'average_precision' in metrics:
        print(f"Avg Prec:  {metrics['average_precision']:.4f}")
    print(f"{'='*60}\n")


def create_metrics_table(results_dict):
    """Create a comparison table of multiple models"""
    df = pd.DataFrame(results_dict).T
    df = df.round(4)
    df = df.sort_values('f1', ascending=False)
    return df


def highlight_offensive_text(text, keywords=None):
    """
    Highlight offensive keywords in text for visualization
    Returns: List of (word, is_offensive) tuples
    """
    if keywords is None:
        keywords = config.OFFENSIVE_KEYWORDS
    
    words = str(text).lower().split()
    highlighted = []
    
    for word in words:
        # Check if word or any part contains offensive keyword
        is_offensive = any(kw in word for kw in keywords)
        highlighted.append((word, is_offensive))
    
    return highlighted


def create_confidence_label(confidence, prediction):
    """Create a human-readable confidence label"""
    if prediction == 1:  # Bullying
        if confidence >= 0.9:
            return f"⚠️ High Confidence ({confidence:.1%})"
        elif confidence >= 0.7:
            return f"⚠️ Moderate Confidence ({confidence:.1%})"
        else:
            return f"⚠️ Low Confidence ({confidence:.1%})"
    else:  # Not bullying
        if confidence >= 0.9:
            return f"✅ Safe ({confidence:.1%})"
        elif confidence >= 0.7:
            return f"✅ Likely Safe ({confidence:.1%})"
        else:
            return f"⚠️ Uncertain ({confidence:.1%})"


def format_category_name(category):
    """Format category name for display"""
    category_map = {
        'harassment': '👤 Harassment',
        'hate_speech': '🚫 Hate Speech',
        'offensive': '😠 Offensive Language',
        'threat': '⚠️ Threat/Violence',
        'normal': '✅ Normal Communication'
    }
    return category_map.get(category, category.replace('_', ' ').title())


def format_severity_badge(severity):
    """Format severity level with emoji"""
    severity_map = {
        'severe': '🔴 Severe',
        'moderate': '🟡 Moderate',
        'mild': '🟢 Mild',
        'none': '✅ None'
    }
    return severity_map.get(severity, severity.title())


def create_logger(name, log_file=None):
    """Create a logger for tracking training/inference"""
    import logging
    
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(config.LOG_FORMAT)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler
    if log_file:
        os.makedirs(config.LOGS_DIR, exist_ok=True)
        file_handler = logging.FileHandler(
            os.path.join(config.LOGS_DIR, log_file)
        )
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


def get_timestamp():
    """Get current timestamp string"""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def ensure_dir(directory):
    """Ensure directory exists"""
    os.makedirs(directory, exist_ok=True)
    return directory


def count_parameters(model):
    """Count trainable parameters in a PyTorch/TensorFlow model"""
    try:
        # PyTorch
        return sum(p.numel() for p in model.parameters() if p.requires_grad)
    except:
        try:
            # TensorFlow/Keras
            return model.count_params()
        except:
            return None


def plot_training_history(history, save_path=None):
    """Plot training history (loss and accuracy curves)"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
    
    # Loss curve
    ax1.plot(history['train_loss'], label='Train Loss', marker='o')
    if 'val_loss' in history:
        ax1.plot(history['val_loss'], label='Val Loss', marker='s')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss')
    ax1.set_title('Training and Validation Loss')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Accuracy curve
    ax2.plot(history['train_acc'], label='Train Accuracy', marker='o')
    if 'val_acc' in history:
        ax2.plot(history['val_acc'], label='Val Accuracy', marker='s')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Accuracy')
    ax2.set_title('Training and Validation Accuracy')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=config.DPI, bbox_inches='tight')
        print(f"📊 Training history saved: {save_path}")
    
    return fig


def get_best_model_info(results_dict, metric='f1'):
    """Get the best performing model based on a metric"""
    best_model = max(results_dict.items(), key=lambda x: x[1].get(metric, 0))
    return best_model[0], best_model[1]


def format_time(seconds):
    """Format seconds to human readable time"""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{seconds/60:.1f}m"
    else:
        return f"{seconds/3600:.1f}h"


def create_word_frequency_dict(texts, top_n=50):
    """Create word frequency dictionary from texts"""
    from collections import Counter
    
    all_words = []
    for text in texts:
        words = str(text).lower().split()
        all_words.extend(words)
    
    word_freq = Counter(all_words)
    return dict(word_freq.most_common(top_n))


def batch_iterator(data, batch_size):
    """Create batches from data"""
    for i in range(0, len(data), batch_size):
        yield data[i:i + batch_size]


class PerformanceTracker:
    """Track and compare model performance across experiments"""
    
    def __init__(self, save_path=None):
        self.results = {}
        self.save_path = save_path or os.path.join(config.PAPER_DIR, 'performance_tracker.json')
    
    def add_result(self, model_name, metrics, metadata=None):
        """Add experiment result"""
        self.results[model_name] = {
            'metrics': metrics,
            'metadata': metadata or {},
            'timestamp': get_timestamp()
        }
    
    def save(self):
        """Save tracker to disk"""
        save_results(self.results, os.path.basename(self.save_path), 
                    output_dir=os.path.dirname(self.save_path))
    
    def load(self):
        """Load tracker from disk"""
        if os.path.exists(self.save_path):
            with open(self.save_path, 'r') as f:
                self.results = json.load(f)
    
    def get_best(self, metric='f1'):
        """Get best model by metric"""
        if not self.results:
            return None
        
        best = max(self.results.items(), 
                  key=lambda x: x[1]['metrics'].get(metric, 0))
        return best
    
    def compare(self):
        """Get comparison DataFrame"""
        if not self.results:
            return None
        
        rows = []
        for name, data in self.results.items():
            row = {'model': name}
            row.update(data['metrics'])
            rows.append(row)
        
        return pd.DataFrame(rows).sort_values('f1', ascending=False)


if __name__ == "__main__":
    print("🛠️  Utilities module loaded successfully")
    print(f"📁 Models directory: {config.MODELS_DIR}")
    print(f"📊 Visualizations directory: {config.VIZ_DIR}")
    print(f"📝 Logs directory: {config.LOGS_DIR}")
