"""
Configuration file for Cyberbullying Detection System
"""
import os

# Project directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
MODELS_DIR = os.path.join(BASE_DIR, 'models')
VIZ_DIR = os.path.join(BASE_DIR, 'visualizations')
LOGS_DIR = os.path.join(BASE_DIR, 'logs')
STATIC_DIR = os.path.join(BASE_DIR, 'static')
PAPER_DIR = os.path.join(BASE_DIR, 'paper_outputs')

# Dataset paths
TEXT_DATASET = os.path.join(DATA_DIR, 'Approach to Social Media Cyberbullying and Harassment Detection Using Advanced Machine Learning.csv')
REDDIT_DATASET = os.path.join(DATA_DIR, 'reddit_comments.csv')
TWEETS_DATASET = os.path.join(DATA_DIR, 'cyberbullying_tweets.csv')
IMAGES_DIR = os.path.join(DATA_DIR, 'images')
MEMES_DIR = os.path.join(DATA_DIR, 'memes')

# Model settings
RANDOM_SEED = 42
TEST_SIZE = 0.2
VAL_SIZE = 0.1
BATCH_SIZE = 32
MAX_LENGTH = 128  # For BERT tokenization
EPOCHS_BERT = 3
EPOCHS_LSTM = 10
EPOCHS_CNN = 15
LEARNING_RATE = 2e-5

# Text preprocessing
MIN_WORD_LENGTH = 2
MAX_FEATURES_TFIDF = 10000
NGRAM_RANGE = (1, 2)

# Image settings
IMG_SIZE = (224, 224)
IMG_CHANNELS = 3
IMG_AUGMENTATION = True

# Categories and severity
CATEGORIES = ['harassment', 'hate_speech', 'offensive', 'threat', 'normal']
SEVERITY_LEVELS = ['mild', 'moderate', 'severe', 'none']
BINARY_LABELS = ['Bullying', 'Not-Bullying']

# Model names
TEXT_MODELS = ['bert', 'distilbert', 'lstm', 'cnn_text', 'svm', 'logistic', 'random_forest']
IMAGE_MODELS = ['resnet50', 'efficientnet', 'vgg16', 'mobilenet']
MULTIMODAL_MODELS = ['ensemble', 'attention']

# Visualization settings
DPI = 300
FIGURE_SIZE = (10, 8)
COLOR_SCHEME = 'viridis'
FONT_SIZE = 12

# Performance targets
TARGET_ACCURACY_TEXT = 0.90
TARGET_ACCURACY_IMAGE = 0.85
TARGET_ACCURACY_MULTIMODAL = 0.92
TARGET_PRECISION = 0.88
TARGET_RECALL = 0.85

# Streamlit settings
PAGE_TITLE = "Cyberbullying Detection System"
PAGE_ICON = "🛡️"
LAYOUT = "wide"
SIDEBAR_STATE = "expanded"

# API settings
API_PORT = 8000
MAX_UPLOAD_SIZE = 10  # MB

# Offensive keywords for highlighting
OFFENSIVE_KEYWORDS = [
    'fuck', 'shit', 'bitch', 'nigger', 'stupid', 'idiot', 'hate', 'kill', 
    'die', 'ugly', 'loser', 'worthless', 'trash', 'scum', 'slut', 'whore',
    'dumb', 'fat', 'gay', 'retard', 'asshole', 'bastard', 'cunt', 'dick'
]

# OCR settings
OCR_ENGINE = 'easyocr'  # 'tesseract' or 'easyocr'
OCR_LANGUAGES = ['en']
OCR_CONFIDENCE_THRESHOLD = 0.5

# Logging
LOG_LEVEL = 'INFO'
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

# Model checkpoints
CHECKPOINT_DIR = os.path.join(MODELS_DIR, 'checkpoints')
SAVE_BEST_ONLY = True
EARLY_STOPPING_PATIENCE = 3

# Evaluation metrics
METRICS = ['accuracy', 'precision', 'recall', 'f1', 'auc']
AVERAGE_TYPE = 'weighted'  # 'macro', 'weighted', 'micro'

# Cross-validation
CV_FOLDS = 5
CV_STRATIFIED = True

# Data augmentation settings
TEXT_AUG_PROB = 0.3
IMG_AUG_ROTATION = 15
IMG_AUG_FLIP = True
IMG_AUG_CROP = True
IMG_AUG_BRIGHTNESS = 0.2

# BERT model settings
BERT_MODEL_NAME = 'bert-base-uncased'
DISTILBERT_MODEL_NAME = 'distilbert-base-uncased'
MAX_GRAD_NORM = 1.0
WARMUP_STEPS = 0

# LSTM settings
LSTM_UNITS = 128
LSTM_DROPOUT = 0.3
EMBEDDING_DIM = 100
VOCAB_SIZE = 10000

# CNN settings
CNN_FILTERS = [128, 256, 512]
CNN_KERNEL_SIZES = [3, 4, 5]
CNN_DROPOUT = 0.5

# Ensemble settings
ENSEMBLE_WEIGHTS = 'equal'  # 'equal' or 'performance'
VOTING_METHOD = 'soft'  # 'hard' or 'soft'

# Multimodal fusion
FUSION_METHOD = 'concatenate'  # 'concatenate', 'average', 'attention'
TEXT_WEIGHT = 0.6
IMAGE_WEIGHT = 0.4

# Class imbalance handling
USE_CLASS_WEIGHTS = True
USE_SMOTE = True
SMOTE_SAMPLING_STRATEGY = 'auto'

# Inference settings
INFERENCE_BATCH_SIZE = 1
CONFIDENCE_THRESHOLD = 0.5
TOP_K_PREDICTIONS = 3

# Report settings
REPORT_FORMAT = 'pdf'  # 'pdf', 'html', 'json'
INCLUDE_VISUALIZATIONS = True
INCLUDE_EXPLANATIONS = True

# Theme settings for Streamlit
THEME_PRIMARY_COLOR = "#FF4B4B"
THEME_BACKGROUND_COLOR = "#FFFFFF"
THEME_SECONDARY_BACKGROUND = "#F0F2F6"
THEME_TEXT_COLOR = "#262730"
THEME_FONT = "sans serif"

print(f"✅ Configuration loaded successfully")
print(f"📁 Data directory: {DATA_DIR}")
print(f"🤖 Models directory: {MODELS_DIR}")
print(f"📊 Visualizations directory: {VIZ_DIR}")
