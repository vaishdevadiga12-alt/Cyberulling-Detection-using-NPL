"""
Cyberbullying Detection System - Streamlit Web Application
Multi-page application with text analysis, image analysis, batch processing, and visualizations
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
from utils import (load_model, highlight_offensive_text, 
                  create_confidence_label, format_category_name, format_severity_badge)
from preprocessing import TextPreprocessor

# Page configuration
st.set_page_config(
    page_title=config.PAGE_TITLE,
    page_icon=config.PAGE_ICON,
    layout=config.LAYOUT,
    initial_sidebar_state=config.SIDEBAR_STATE
)

# Custom CSS
st.markdown("""
<style>
    /* Main header styling */
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #FF4B4B;
        text-align: center;
        margin-bottom: 2rem;
        padding: 1rem;
    }
    
    /* Sub-header styling */
    .sub-header {
        font-size: 1.5rem;
        color: #262730;
        margin-top: 2rem;
        margin-bottom: 1rem;
        border-bottom: 2px solid #FF4B4B;
        padding-bottom: 0.5rem;
    }
    
    /* Metric card styling */
    .metric-card {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 5px solid #FF4B4B;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        transition: transform 0.2s;
    }
    
    .metric-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    
    /* Badge styling */
    .offensive-word {
        background-color: #FFCDD2;
        padding: 2px 6px;
        border-radius: 3px;
        font-weight: bold;
        color: #C62828;
    }
    
    .safe-badge {
        background-color: #C8E6C9;
        color: #1B5E20;
        padding: 8px 16px;
        border-radius: 8px;
        font-weight: bold;
        font-size: 1.1rem;
        display: inline-block;
    }
    
    .danger-badge {
        background-color: #FFCDD2;
        color: #C62828;
        padding: 8px 16px;
        border-radius: 8px;
        font-weight: bold;
        font-size: 1.1rem;
        display: inline-block;
    }
    
    /* Sidebar styling */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #1e1e1e 0%, #2d2d2d 100%);
    }
    
    /* Make radio buttons more visible */
    .stRadio > label {
        font-weight: 600;
        font-size: 1.1rem;
    }
    
    /* Button styling */
    .stButton > button {
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s;
    }
    
    .stButton > button:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 12px rgba(255, 75, 75, 0.3);
    }
</style>
""", unsafe_allow_html=True)


# Load models (cached)
@st.cache_resource
def load_classification_model():
    """Load the best classification model"""
    # Try to load best model
    models_to_try = ['model_svm', 'model_random_forest', 'model_logistic']
    
    for model_name in models_to_try:
        model = load_model(model_name)
        if model is not None:
            return model, model_name.replace('model_', '')
    
    return None, None


@st.cache_resource
def load_vectorizer_model():
    """Load the TF-IDF vectorizer"""
    return load_model('vectorizer_tfidf')


# Initialize components
text_preprocessor = TextPreprocessor()
model, model_name = load_classification_model()
vectorizer = load_vectorizer_model()


def create_sidebar():
    """Create sidebar navigation"""
    st.sidebar.title("🛡️ Cyberbullying Detection")
    st.sidebar.markdown("---")
    
    st.sidebar.markdown("### 📍 Navigation")
    
    page = st.sidebar.radio(
        "Select a page:",
        ["🏠 Home", "📝 Analyze Text", "🖼️ Analyze Image", "📊 Batch Analysis",
         "📈 Dataset Analysis", "🎯 Model Performance", "ℹ️ About"]
    )
    
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 🔧 System Status")
    
    if model is not None:
        st.sidebar.success(f"✅ Model: {model_name.upper()}")
    else:
        st.sidebar.error("❌ Model not loaded")
    
    if vectorizer is not None:
        st.sidebar.success("✅ Vectorizer: Ready")
    else:
        st.sidebar.error("❌ Vectorizer not loaded")
    
    st.sidebar.markdown("---")
    st.sidebar.info("💡 Navigate through pages using the options above")
    
    return page


# PAGE 1: HOME
def page_home():
    """Home page with overview and statistics"""
    st.markdown("<h1 class='main-header'>🛡️ Cyberbullying Detection System</h1>", 
               unsafe_allow_html=True)
    
    st.markdown("""
    <div style='text-align: center; font-size: 1.2rem; color: #666; margin-bottom: 3rem;'>
        AI-powered system for detecting and preventing cyberbullying across 
        text and image content using machine learning.
    </div>
    """, unsafe_allow_html=True)
    
    # Key features with better styling
    st.markdown("### ✨ Key Features")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div class='metric-card' style='text-align: center;'>
            <h2 style='color: #FF4B4B; margin: 0;'>📝</h2>
            <h3 style='margin: 10px 0;'>Text Analysis</h3>
            <p style='color: #666; margin: 0;'>Real-time detection in posts and comments</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class='metric-card' style='text-align: center;'>
            <h2 style='color: #FF4B4B; margin: 0;'>🖼️</h2>
            <h3 style='margin: 10px 0;'>Image Analysis</h3>
            <p style='color: #666; margin: 0;'>OCR-based meme and screenshot detection</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class='metric-card' style='text-align: center;'>
            <h2 style='color: #FF4B4B; margin: 0;'>📊</h2>
            <h3 style='margin: 10px 0;'>Batch Processing</h3>
            <p style='color: #666; margin: 0;'>Analyze multiple texts at once</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    st.markdown("<h2 class='sub-header'>🚀 Quick Start</h2>", unsafe_allow_html=True)
    
    st.markdown("""
    1. **Analyze Text**: Check social media posts and comments
    2. **Analyze Images**: Upload memes or screenshots with text
    3. **Batch Process**: Upload CSV files for bulk analysis
    4. **View Performance**: Check model metrics and visualizations
    """)
    
    # Model performance metrics
    st.markdown("<h2 class='sub-header'>📈 Current Model Performance</h2>", unsafe_allow_html=True)
    
    metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
    
    with metrics_col1:
        st.metric("Accuracy", "87.1%")
    
    with metrics_col2:
        st.metric("F1-Score", "0.872")
    
    with metrics_col3:
        st.metric("Model", "Linear SVM")


# PAGE 2: ANALYZE TEXT
def page_analyze_text():
    """Text analysis page"""
    st.markdown("<h1 class='main-header'>📝 Text Analysis</h1>", unsafe_allow_html=True)
    
    if model is None or vectorizer is None:
        st.error("⚠️ Model not loaded. Please train the model first.")
        return
    
    st.markdown("Enter text to analyze for cyberbullying content:")
    
    # Initialize session state for text
    if 'sample_text' not in st.session_state:
        st.session_state.sample_text = ""
    
    # Text input
    text_input = st.text_area(
        "Input Text",
        value=st.session_state.sample_text,
        placeholder="Enter social media post, comment, or message...",
        height=150,
        label_visibility="collapsed",
        key="text_area_input"
    )
    
    col1, col2 = st.columns([1, 5])
    with col1:
        analyze_button = st.button("🔍 Analyze", type="primary", use_container_width=True)
    with col2:
        if st.button("Clear", use_container_width=True):
            st.session_state.sample_text = ""
            st.rerun()
    
    if analyze_button and text_input:
        with st.spinner("Analyzing..."):
            # Preprocess
            cleaned_text = text_preprocessor.clean_text(text_input)
            
            # Vectorize
            X = vectorizer.transform([cleaned_text])
            
            # Predict
            prediction = model.predict(X)[0]
            
            try:
                proba = model.predict_proba(X)[0]
                confidence = proba[prediction]
            except:
                try:
                    decision = model.decision_function(X)[0]
                    confidence = 1 / (1 + np.exp(-decision)) if prediction == 1 else 1 / (1 + np.exp(decision))
                except:
                    confidence = 0.75  # Default
            
            # Display results
            st.markdown("---")
            st.markdown("<h2 class='sub-header'>🎯 Analysis Results</h2>", unsafe_allow_html=True)
            
            result_col1, result_col2, result_col3 = st.columns(3)
            
            with result_col1:
                if prediction == 1:
                    st.markdown("<div class='danger-badge'>⚠️ BULLYING DETECTED</div>", 
                              unsafe_allow_html=True)
                else:
                    st.markdown("<div class='safe-badge'>✅ SAFE CONTENT</div>", 
                              unsafe_allow_html=True)
            
            with result_col2:
                st.metric("Confidence", f"{confidence*100:.1f}%")
            
            with result_col3:
                category = "Offensive" if prediction == 1 else "Normal"
                st.markdown(f"**Category:** {format_category_name(category.lower())}")
            
            # Highlight offensive words
            if prediction == 1:
                st.markdown("<h3 class='sub-header'>🔍 Highlighted Terms</h3>", unsafe_allow_html=True)
                
                highlighted = highlight_offensive_text(text_input)
                html_text = " ".join([
                    f"<span class='offensive-word'>{word}</span>" if is_off 
                    else word
                    for word, is_off in highlighted
                ])
                
                st.markdown(f"<p style='font-size: 1.1rem;'>{html_text}</p>", 
                          unsafe_allow_html=True)
            
            # Detailed breakdown
            with st.expander("📊 Detailed Breakdown"):
                st.markdown(f"**Original Text:** {text_input}")
                st.markdown(f"**Cleaned Text:** {cleaned_text}")
                st.markdown(f"**Prediction:** {'Bullying' if prediction == 1 else 'Not-Bullying'}")
                st.markdown(f"**Model Used:** {model_name.upper()}")
    
    # Sample examples
    st.markdown("<h2 class='sub-header'>💡 Try Sample Texts</h2>", unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**⚠️ Potentially Harmful:**")
        if st.button("🔴 Example 1", key="ex1", use_container_width=True):
            st.session_state.sample_text = "You are so stupid and ugly, nobody likes you!"
            st.rerun()
        if st.button("🔴 Example 2", key="ex2", use_container_width=True):
            st.session_state.sample_text = "I hate you, go away loser!"
            st.rerun()
    
    with col2:
        st.markdown("**✅ Safe Content:**")
        if st.button("🟢 Example 3", key="ex3", use_container_width=True):
            st.session_state.sample_text = "Great work! Keep it up!"
            st.rerun()
        if st.button("🟢 Example 4", key="ex4", use_container_width=True):
            st.session_state.sample_text = "Thank you for your help!"
            st.rerun()


# PAGE 3: ANALYZE IMAGE
def page_analyze_image():
    """Image/meme analysis page"""
    st.markdown("<h1 class='main-header'>🖼️ Image/Meme Analysis</h1>", unsafe_allow_html=True)
    
    if model is None or vectorizer is None:
        st.error("⚠️ Model not loaded. Please check system status.")
        return
    
    st.markdown("Upload an image or meme containing text to analyze:")
    
    uploaded_file = st.file_uploader("Choose an image file", type=['png', 'jpg', 'jpeg'])
    
    if uploaded_file is not None:
        # Display image
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Image", use_column_width=True)
        
        if st.button("🔍 Analyze Image", type="primary"):
            # Try to import OCR utilities
            try:
                from ocr_utils import extract_text_from_image, check_ocr_availability
                
                ocr_status = check_ocr_availability()
                
                if not ocr_status['any_available']:
                    st.warning("⚠️ OCR feature requires additional setup.")
                    st.markdown("""
                    **To enable this feature, install one of:**
                    - **EasyOCR**: `pip install easyocr`
                    - **Tesseract**: Download from [GitHub](https://github.com/UB-Mannheim/tesseract/wiki) and `pip install pytesseract`
                    
                    Alternative: Use 'Analyze Text' page to manually enter text.
                    """)
                else:
                    # Extract text from image
                    with st.spinner("🔍 Extracting text from image..."):
                        import numpy as np
                        image_array = np.array(image)
                        extracted_text = extract_text_from_image(image_array)
                        
                        if extracted_text:
                            st.success("✓ Text extracted successfully")
                            st.markdown("### 📝 Extracted Text:")
                            st.info(extracted_text)
                            
                            # Analyze the extracted text
                            st.markdown("### 🎯 Analysis Result:")
                            
                            cleaned_text = text_preprocessor.clean_text(extracted_text)
                            X = vectorizer.transform([cleaned_text])
                            prediction = model.predict(X)[0]
                            
                            try:
                                proba = model.predict_proba(X)[0]
                                confidence = proba[prediction]
                            except:
                                confidence = 0.75
                            
                            if prediction == 1:
                                st.error(f"⚠️ **CYBERBULLYING DETECTED** (Confidence: {confidence:.1%})")
                            else:
                                st.success(f"✓ **SAFE CONTENT** (Confidence: {confidence:.1%})")
                        else:
                            st.warning("⚠️ No text detected in the image.")
                            
            except ImportError:
                st.error("❌ OCR utilities not available.")
                st.markdown("**Install EasyOCR**: `pip install easyocr`")
            except Exception as e:
                st.error(f"❌ Error: {e}")


# PAGE 4: BATCH ANALYSIS
def page_batch_analysis():
    """Batch processing page"""
    st.markdown("<h1 class='main-header'>📊 Batch Analysis</h1>", unsafe_allow_html=True)
    
    if model is None or vectorizer is None:
        st.error("⚠️ Model not loaded. Please train the model first.")
        return
    
    st.markdown("Upload a CSV file with a 'text' column for bulk analysis:")
    
    uploaded_file = st.file_uploader("Choose a CSV file", type=['csv'])
    
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            st.success(f"✅ Loaded {len(df)} rows")
            
            st.dataframe(df.head(), use_container_width=True)
            
            if 'text' not in df.columns and 'Text' not in df.columns:
                st.error("❌ CSV must contain a 'text' or 'Text' column")
                return
            
            text_col = 'text' if 'text' in df.columns else 'Text'
            
            if st.button("🚀 Analyze All", type="primary"):
                with st.spinner("Processing..."):
                    # Clean texts
                    df['cleaned_text'] = df[text_col].apply(text_preprocessor.clean_text)
                    
                    # Vectorize
                    X = vectorizer.transform(df['cleaned_text'])
                    
                    # Predict
                    df['prediction'] = model.predict(X)
                    df['label'] = df['prediction'].apply(lambda x: 'Bullying' if x == 1 else 'Not-Bullying')
                    
                    try:
                        proba = model.predict_proba(X)
                        df['confidence'] = [proba[i][df['prediction'].iloc[i]] for i in range(len(df))]
                    except:
                        df['confidence'] = 0.75
                    
                    # Display results
                    st.success("✅ Analysis complete!")
                    
                    # Summary
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Analyzed", len(df))
                    with col2:
                        bullying_count = (df['prediction'] == 1).sum()
                        st.metric("Bullying Detected", bullying_count)
                    with col3:
                        safe_count = (df['prediction'] == 0).sum()
                        st.metric("Safe Content", safe_count)
                    
                    # Results table
                    st.dataframe(df[[text_col, 'label', 'confidence']], use_container_width=True)
                    
                    # Download results
                    csv = df.to_csv(index=False).encode('utf-8')
                    st.download_button(
                        label="📥 Download Results",
                        data=csv,
                        file_name="cyberbullying_analysis_results.csv",
                        mime="text/csv"
                    )
        
        except Exception as e:
            st.error(f"❌ Error processing file: {e}")


# PAGE 5: DATASET ANALYSIS
def page_dataset_analysis():
    """Dataset statistics page"""
    st.markdown("<h1 class='main-header'>📈 Dataset Analysis</h1>", unsafe_allow_html=True)
    
    try:
        # Load dataset
        df = pd.read_csv(config.TEXT_DATASET, encoding='utf-8')
        
        st.success(f"✅ Loaded dataset: {len(df)} samples")
        
        # Basic stats
        st.markdown("<h2 class='sub-header'>📊 Dataset Overview</h2>", unsafe_allow_html=True)
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Samples", len(df))
        with col2:
            st.metric("Columns", len(df.columns))
        with col3:
            st.metric("Missing Values", df.isnull().sum().sum())
        with col4:
            avg_length = df[df.columns[0]].astype(str).str.len().mean()
            st.metric("Avg Text Length", f"{avg_length:.0f}")
        
        # Sample data
        st.markdown("<h2 class='sub-header'>🔍 Sample Data</h2>", unsafe_allow_html=True)
        st.dataframe(df.head(10), use_container_width=True)
        
    except Exception as e:
        st.error(f"❌ Error loading dataset: {e}")


# PAGE 6: MODEL PERFORMANCE
def page_model_performance():
    """Model performance metrics page"""
    st.markdown("<h1 class='main-header'>🎯 Model Performance</h1>", unsafe_allow_html=True)
    
    st.markdown("### 📊 Trained Models Comparison")
    
    # Display model metrics
    model_metrics = pd.DataFrame({
        'Model': ['Linear SVM', 'Random Forest', 'Logistic Regression'],
        'Accuracy': ['87.11%', '85.69%', '86.52%'],
        'F1-Score': ['0.872', '0.857', '0.866'],
        'AUC': ['0.933', '0.931', '0.921'],
        'Status': ['✅ Best', '✅ Trained', '✅ Trained']
    })
    
    st.dataframe(model_metrics, use_container_width=True, hide_index=True)
    
    st.success("🏆 Best Model: **LINEAR SVM** (87.11% accuracy)")
    
    # Display visualizations
    st.markdown("### 📈 Performance Visualizations")
    
    viz_files = {
        'Confusion Matrices': 'confusion_matrices_combined.png',
        'ROC Curves': 'roc_curves.png',
        'Precision-Recall Curves': 'precision_recall_curves.png'
    }
    
    for title, filename in viz_files.items():
        filepath = os.path.join(config.VIZ_DIR, filename)
        if os.path.exists(filepath):
            with st.expander(f"📊 {title}", expanded=False):
                st.image(filepath, use_column_width=True)
        else:
            st.info(f"ℹ️ {title} will appear after model training")


# PAGE 7: ABOUT
def page_about():
    """About page with project information"""
    st.markdown("<h1 class='main-header'>ℹ️ About</h1>", unsafe_allow_html=True)
    
    st.markdown("""
    ## 🎯 Project Overview
    
    This Cyberbullying Detection System uses Natural Language Processing (NLP) and 
    Machine Learning to identify cyberbullying content in text and images.
    
    ### 🔬 Methodology
    
    1. **Data Preprocessing**: Text cleaning, tokenization, normalization
    2. **Feature Extraction**: TF-IDF vectorization
    3. **Model Training**: SVM, Random Forest, Logistic Regression
    4. **Evaluation**: Accuracy, precision, recall, F1-score
    5. **Deployment**: Real-time web application
    
    ### 🤖 Models
    
    - **Linear SVM**: 87.1% accuracy (current best)
    - **Random Forest**: 85.7% accuracy
    - **Logistic Regression**: 86.5% accuracy
    
    ### 👥 Use Cases
    
    - Social media content moderation
    - Educational institution monitoring
    - Parental control applications
    - Online community management
    
    ### 📚 Technology Stack
    
    - **Backend**: Python, scikit-learn, NLTK
    - **Frontend**: Streamlit
    - **OCR**: EasyOCR, Tesseract
    - **Visualization**: Matplotlib, Seaborn
    """)
    
    st.markdown("---")
    st.markdown("*For questions or feedback, please contact the development team.*")


# Main app
def main():
    """Main application logic"""
    page = create_sidebar()
    
    if page == "🏠 Home":
        page_home()
    elif page == "📝 Analyze Text":
        page_analyze_text()
    elif page == "🖼️ Analyze Image":
        page_analyze_image()
    elif page == "📊 Batch Analysis":
        page_batch_analysis()
    elif page == "📈 Dataset Analysis":
        page_dataset_analysis()
    elif page == "🎯 Model Performance":
        page_model_performance()
    elif page == "ℹ️ About":
        page_about()


if __name__ == "__main__":
    main()
