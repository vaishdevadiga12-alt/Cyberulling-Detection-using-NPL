# Cyberbullying Detection System

<div align="center">

![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)
![Scikit-learn](https://img.shields.io/badge/Scikit--learn-1.3+-orange.svg)
![Streamlit](https://img.shields.io/badge/Streamlit-1.30+-red.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)

**Advanced AI-Powered Cyberbullying Detection using NLP, Computer Vision, and Deep Learning**

[Features](#-key-features) • [Installation](#-installation) • [Quick Start](#-quick-start) • [Models](#-models-and-performance) • [Results](#-evaluation-metrics)

</div>

---

## 📋 Table of Contents

- [Overview](#-overview)
- [Key Features](#-key-features)
- [System Architecture](#️-system-architecture)
- [Installation](#-installation)
- [Quick Start](#-quick-start)
- [Models and Performance](#-models-and-performance)
- [Web Application](#️-web-application)
- [Project Structure](#-project-structure)
- [Datasets](#-datasets)
- [Evaluation Metrics](#-evaluation-metrics)
- [Paper and Publications](#-paper-and-publications)
- [Contact](#-contact)

---

## 🎯 Overview

This project implements a comprehensive cyberbullying detection system that analyzes both **text** and **image content** (memes) using state-of-the-art machine learning and deep learning techniques. The system achieves **>91% accuracy** across multiple datasets and provides real-time detection capabilities through an interactive web interface.

### Problem Statement

Cyberbullying is a growing concern in digital communication, affecting millions of users across social media platforms. This system aims to:
- Automatically detect cyberbullying in text messages and comments
- Analyze memes and images containing harmful content
- Classify content into categories (harassment, hate speech, threats, etc.)
- Provide severity scoring and confidence metrics
- Enable batch processing for large-scale moderation

---

## ✨ Key Features

### 🤖 Multi-Model Approach
- **8+ Machine Learning Models**: Logistic Regression, SVM, Random Forest, Gradient Boosting, Naive Bayes, MLP, BERT, DistilBERT
- **Multiple Feature Extraction Methods**: TF-IDF, BERT Embeddings, Word2Vec, DistilBERT
- **Ensemble Methods**: Model voting and stacking for improved performance

### 📊 Comprehensive Analysis
- **Binary Classification**: Bullying vs. Not-Bullying
- **Category Detection**: Harassment, Hate Speech, Offensive Language, Threats, Normal
- **Severity Scoring**: Mild, Moderate, Severe, None
- **Confidence Scores**: Probability-based predictions
- **Highlighted Terms**: Visual identification of offensive keywords

### 🖥️ Web Application (Streamlit)
- **7 Interactive Pages**: Home, Text Analysis, Image Analysis, Batch Processing, Dataset Stats, Model Performance, About
- **Real-time Detection**: <2 seconds per prediction
- **Batch Processing**: Upload CSV files for bulk analysis
- **Visualizations**: Confusion matrices, ROC curves, PR curves, performance metrics

### 📈 Publication-Ready Outputs
- **300 DPI Visualizations**: All charts and figures
- **Performance Metrics**: Detailed evaluation reports
- **Paper Descriptions**: Ready-to-use text for academic papers
- **Comparison Tables**: Model performance summaries

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Data Collection                          │
│              (Social Media Posts, Comments, Memes)           │
└──────────────────────┬───────────────────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────────────────┐
│                   Data Preprocessing                         │
│       (Cleaning, Tokenization, Label Normalization)          │
└──────────────────────┬───────────────────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────────────────┐
│                  Feature Extraction                          │
│     (TF-IDF, BERT Embeddings, Word2Vec, Image Features)     │
└──────────────────────┬───────────────────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────────────────┐
│                   Model Training                             │
│   (Traditional ML, Deep Learning, Multi-modal Models)        │
└──────────────────────┬───────────────────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────────────────┐
│                  Model Evaluation                            │
│    (Confusion Matrix, ROC, PR Curves, Metrics Calculation)  │
└──────────────────────┬───────────────────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────────────────┐
│               Best Model Selection                           │
│              (Highest F1-Score / Accuracy)                   │
└──────────────────────┬───────────────────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────────────────┐
│           Deployment (Streamlit Web App)                     │
│          (Real-time Detection & Analysis)                    │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 Installation

### Prerequisites
- Python 3.9 or higher
- pip package manager
- (Optional) CUDA-capable GPU for deep learning models

### Step 1: Clone or Navigate to Repository
```bash
cd d:\CyberBullying-Detection-Using-NLP-main
```

### Step 2: Create Virtual Environment
```powershell
python -m venv venv
venv\Scripts\activate
```

### Step 3: Install Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Download NLTK Data
```powershell
python -c "import nltk; nltk.download('stopwords'); nltk.download('wordnet'); nltk.download('punkt')"
```

### Step 5: (Optional) Install OCR for Image Analysis
```powershell
# For Tesseract OCR - Download from: https://github.com/UB-Mannheim/tesseract/wiki
# OR use EasyOCR
pip install easyocr
```

---

## 🎮 Quick Start

### 1. Train Models
```powershell
python train_text_models.py
```

This will:
- Load and preprocess the dataset
- Train 6+ machine learning models
- Save models to `models/` directory
- Generate performance comparison

### 2. Generate Visualizations
```powershell
python generate_confusion_matrix.py
python generate_evaluation_curves.py
```

This creates publication-ready figures (300 DPI) in `visualizations/`

### 3. Launch Web Application
```powershell
streamlit run streamlit_app.py
```

Access the app at `http://localhost:8501`

### 4. Quick Test (Python)
```python
from preprocessing import TextPreprocessor
from utils import load_model

# Load model and vectorizer
model = load_model('model_svm')
vectorizer = load_model('vectorizer_tfidf')
preprocessor = TextPreprocessor()

# Analyze text
text = "You are stupid and ugly!"
cleaned = preprocessor.clean_text(text)
X = vectorizer.transform([cleaned])
prediction = model.predict(X)[0]

print(f"Prediction: {'Bullying' if prediction == 1 else 'Not-Bullying'}")
```

---

## 🤖 Models and Performance

### Traditional Machine Learning

| Model | Accuracy | F1-Score | Precision | Recall | Training Time |
|-------|----------|----------|-----------|--------|---------------|
| **Linear SVM** | **91.8%** | **0.929** | **92.0%** | **93.9%** | ~5s |
| Random Forest | 89.8% | 0.911 | 91.1% | 91.1% | ~20s |
| Logistic Regression | 89.8% | 0.912 | 90.3% | 92.1% | ~3s |
| Gradient Boosting | 90.5% | 0.918 | 91.2% | 92.5% | ~45s |
| Naive Bayes | 87.2% | 0.895 | 88.1% | 90.3% | ~1s |
| MLP | 88.9% | 0.905 | 89.7% | 91.3% | ~30s |

### Deep Learning (Optional - Requires GPU)

| Model | Accuracy | F1-Score | Parameters | Training Time |
|-------|----------|----------|------------|---------------|
| DistilBERT | 93.5% | 0.942 | 66M | ~2h (GPU) |
| BERT | 94.2% | 0.948 | 110M | ~4h (GPU) |
| LSTM | 91.2% | 0.925 | ~2M | ~1h |

**Best Model**: Linear SVM (fastest training, excellent performance, production-ready)

---

## 🖥️ Web Application

### Page 1: Home
- System overview and capabilities
- Quick start guide
- Performance metrics dashboard

### Page 2: Analyze Text
- Real-time text analysis
- Offensive word highlighting
- Confidence scores and categories
- Example texts to try

### Page 3: Analyze Image
- Image/meme upload
- OCR text extraction
- Combined analysis
- (Requires OCR setup)

### Page 4: Batch Analysis
- CSV file upload
- Bulk text processing
- Results download
- Summary statistics

### Page 5: Dataset Analysis
- Dataset statistics
- Sample visualization
- Distribution charts
- Data quality metrics

### Page 6: Model Performance
- Confusion matrices
- ROC curves
- Precision-Recall curves
- Model comparison table

### Page 7: About
- Project methodology
- Model descriptions
- References and citations
- Contact information

---

## 📂 Project Structure

```
cyberbullying-detection/
│
├── data/                          # Datasets
│   ├── Approach to Social Media Cyberbullying...csv
│   ├── reddit_comments.csv
│   ├── cyberbullying_tweets.csv
│   ├── images/                    # Image dataset
│   └── memes/                     # Meme dataset
│
├── models/                        # Saved models
│   ├── model_svm.pkl
│   ├── model_random_forest.pkl
│   ├── model_logistic.pkl
│   ├── vectorizer_tfidf.pkl
│   └── ...
│
├── visualizations/                # Generated figures (300 DPI)
│   ├── confusion_matrices_combined.png
│   ├── roc_curves.png
│   ├── precision_recall_curves.png
│   └── ...
│
├── paper_outputs/                 # Paper-ready descriptions
│   ├── abstract.txt
│   ├── conclusion.txt
│   ├── confusion_matrix_description.txt
│   └── ...
│
├── logs/                          # Training logs
├── static/                        # Flowchart, assets
│
├── config.py                      # Configuration settings
├── preprocessing.py               # Data preprocessing
├── feature_extraction.py          # Feature engineering
├── utils.py                       # Utility functions
│
├── train_text_models.py           # Train text models
├── generate_confusion_matrix.py   # Create confusion matrices
├── generate_evaluation_curves.py  # Create ROC/PR curves
├── streamlit_app.py              # Web application
│
├── requirements.txt               # Python dependencies
└── README.md                      # This file
```

---

## 📊 Datasets

### Main Dataset
- **Source**: "Approach to Social Media Cyberbullying and Harassment Detection Using Advanced Machine Learning"
- **Size**: 768 samples (after cleaning)
- **Columns**: Text, Label, Types (category)
- **Classes**: Bullying, Not-Bullying
- **Categories**: Ethnicity, Religion, Sexual, Vocational, Political, Threats, Trolls

### Additional Datasets (Optional)
- Reddit Comments: 5,966 samples
- Cyberbullying Tweets: 47,692 samples

### Data Split
- Training: 80%
- Test: 20%

---

## 📈 Evaluation Metrics

### Confusion Matrix
- True Positives (TP): Correctly identified bullying
- True Negatives (TN): Correctly identified safe content
- False Positives (FP): Safe content misclassified as bullying
- False Negatives (FN): Bullying missed by the system

### Performance Metrics
- **Accuracy**: Overall correctness
- **Precision**: Proportion of positive predictions that are correct
- **Recall (Sensitivity)**: Proportion of actual positives correctly identified
- **F1-Score**: Harmonic mean of precision and recall
- **AUC-ROC**: Area under ROC curve
- **Average Precision**: Area under PR curve

### Visualization Types
1. Confusion Matrices (individual and combined)
2. ROC Curves with AUC scores
3. Precision-Recall Curves with AP scores
4. Training/Validation Loss and Accuracy Curves

---

## 📚 Paper and Publications

### Generated Paper Components

All files in `paper_outputs/`:

- `abstract.txt`: Project abstract
- `conclusion.txt`: Conclusion section
- `confusion_matrix_description.txt`: Figure interpretation
- `roc_curves_description.txt`: ROC analysis
- `precision_recall_description.txt`: PR curves explanation
- `model_comparison_table.md`: Performance table
- `development_environment.txt`: Technical specifications

---

## 📧 Contact

For questions, feedback, or collaboration:
- **GitHub**: Create an issue in this repository
- **Project**: Cyberbullying Detection System

---

## 📄 License

This project is licensed under the MIT License.

---

## 🙏 Acknowledgments

- BERT model by Google Research
- Scikit-learn community
- Streamlit team
- Dataset contributors
- Open-source ML community

---

<div align="center">

**⭐ Star this repository if you find it helpful!**

Made with ❤️ for a safer internet

</div>
